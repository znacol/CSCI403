Zoe Nacol
CSCI 403 Fall 2015
Colorado School of Mines
Project 02

1. Travis Johnson
2. Trouble with reading and understanding the documentation and lack of knowledge of syntax
3. Learned more on psql syntax
4. 3 hours
