Zoe Nacol
CSCI 403 Fall 2015
Colorado School of Mines
Project 03

1. Travis Johnson
2. Making the design decisions was the most difficult part.
3. I enjoyed how it really made me think about the best possible design.
4. ~3-4 hours were spent on this assignment
